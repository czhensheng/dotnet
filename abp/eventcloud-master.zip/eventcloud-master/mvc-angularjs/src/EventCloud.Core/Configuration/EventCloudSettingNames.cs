﻿namespace EventCloud.Configuration
{
    public class EventCloudSettingNames
    {
        public const string MaxAllowedEventRegistrationCountInLast30DaysPerUser = "EventCloud.MaxAllowedEventRegistrationCountInLast30DaysPerUser";
    }
}