﻿using Abp.Authorization.Roles;
using EventCloud.Users;

namespace EventCloud.Authorization.Roles
{
    public class Role : AbpRole<User>
    {

    }
}