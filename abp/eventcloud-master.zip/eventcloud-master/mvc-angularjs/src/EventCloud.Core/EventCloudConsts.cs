﻿namespace EventCloud
{
    public class EventCloudConsts
    {
        public const string LocalizationSourceName = "EventCloud";
    }
}