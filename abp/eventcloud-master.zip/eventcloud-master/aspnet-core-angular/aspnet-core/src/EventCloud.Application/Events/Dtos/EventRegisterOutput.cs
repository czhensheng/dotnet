﻿namespace EventCloud.Events.Dtos
{
    public class EventRegisterOutput
    {
        public int RegistrationId { get; set; }
    }
}
